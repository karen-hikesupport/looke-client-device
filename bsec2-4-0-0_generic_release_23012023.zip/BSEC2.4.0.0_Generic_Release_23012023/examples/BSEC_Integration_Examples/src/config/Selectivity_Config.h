#include <stdint.h>

extern const uint8_t Selectivity_config[1974];

